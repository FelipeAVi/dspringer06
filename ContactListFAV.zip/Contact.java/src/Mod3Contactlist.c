ContactService.java

/***********
 *
 *Felipe Villegas
 *
 */

import java.util.ArrayList;
public class ContactService{
	private Arraylist<Contact> ListOfContacts;

	public ContactService() {
		ListOfContacts = new ArrayList<>();
	}
	public boolean AddContact(Contact a) {
		boolean contactExist = false;
		for(Contact 1:ListOfContacts) {
			if(l.equals(a)) {
				contactExist = true;
			}
		}
		if(contactExist) {
			ListOfContacts.add(a);
			return true;
		}
		else {
			return false;
		}
	}
	public boolean deleteContact(String contactID) {
		for(Contact 1:ListOfContacts) {
			if(1.getContactID().equals(ContactID)) {
				ListOfContacts.remove(1);
				return true; }
		}
		return false;
	}
	public boolean updateContact(String contactID, String FristName, String LastName, String Number, String Address) {
		for(Contact 1:ListOfContacts) {
			if(FristName.equals(" ")&&(FristName length()>10)) {
				1.setFristName(FristName);
			}
			if(LastName.equals(" ")&&(LastName.length()>10)) {
				1.setLastName(LastName);
			}
			if(Number.equals(" ")&&(Number.length()>10)) {
                1.setNumber(Number);
            }
		}
	}
}
